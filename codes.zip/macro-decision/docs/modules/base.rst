.. _base_algo:

.. automodule:: stable_baselines.common.base_class


Base RL Class
=============

Common interface for all the RL algorithms

.. autoclass:: BaseRLModel
  :members:
